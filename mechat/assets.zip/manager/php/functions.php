<?php

/*
    LOAD MECHAT PHP FUNCTIONS "mechat/php/functions.php"
*/
include(implode('/',array_slice(explode('/', dirname(str_replace('\\', '/', __FILE__))),0,count(explode('/',dirname(str_replace('\\', '/', __FILE__))))-2)).'/php/functions.php');

?>
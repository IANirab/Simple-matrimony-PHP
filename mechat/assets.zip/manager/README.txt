In this folder is stored files of the meChat Manager.

IMPORTANT: Do not delete the file ".htaccess", because it protects the 
config file "config.json".
IMPORTANT: This folder should be inside the folder "mechat/".
In this folder is stored the stylesheets of the meChat (mechat.css). In the 
subfolder "template" is used to store the custom stylesheets.

IMPORTANT: If you want to change any color meChat, I recommend that 
you change in the configuration file (mechat/config.json) or use the manager.
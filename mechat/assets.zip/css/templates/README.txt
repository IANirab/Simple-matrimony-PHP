The stylesheet "developed.css" found in this folder was created to 
have a base for the use of elements (<img>, <div>, <i>...) in the meChat.
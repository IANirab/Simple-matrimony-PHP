In this folder is stored the javascripts files of meChat (mechat.js). In the 
subfolder "templates" is used to store the javascript files using the 
functions of "mechat.js".

IMPORTANT: In "mechat.js" file you can change the colors of meChat, 
but we recommend that you use the configuration file (mechat/config.json)
or use the manager.
In this folder is stored files using the functions of the "mechat.js" file, 
found in the parent folder.
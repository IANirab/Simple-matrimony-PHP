In this folder is stored the sounds of the meChat, it is important that these 
sounds can be played on HTML5.

http://www.w3schools.com/html/html5_audio.asp